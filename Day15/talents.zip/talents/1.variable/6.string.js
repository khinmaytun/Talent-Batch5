// String Introduction
let singleQuoteString = 'Hello, world!';
let doubleQuoteString = "Hello, world!";
let templateLiteralString = `Hello, world!`;

console.log(singleQuoteString); // Output: Hello, world!
console.log(doubleQuoteString); // Output: Hello, world!
console.log(templateLiteralString); // Output: Hello, world!

// String Properties
let str = 'Hello, world!';
console.log(str.length); // Output: 13

// String Methods

// charAt()
console.log(str.charAt(0)); // Output: H

// concat()
let str1 = 'Hello';
let str2 = 'World';
console.log(str1.concat(', ', str2)); // Output: Hello, World

// includes()
console.log(str.includes('world')); // Output: true

// indexOf()
console.log(str.indexOf('world')); // Output: 7

// slice()
console.log(str.slice(0, 5)); // Output: Hello

// substring()
console.log(str.substring(0, 5)); // Output: Hello

// toLowerCase() and toUpperCase()
console.log(str.toLowerCase()); // Output: hello, world!
console.log(str.toUpperCase()); // Output: HELLO, WORLD!

// trim()
let strWithWhitespace = '   Hello, world!   ';
console.log(strWithWhitespace.trim()); // Output: Hello, world!

// split()
let arr = str.split(', ');
console.log('split function ',arr); // Output: ['Hello', 'world!']

// replace()
let newStr = str.replace('world', 'JavaScript');
console.log(newStr); // Output: Hello, JavaScript!

// Template Literals
let name = 'Alice';
let greeting = `Hello, ${name}!`;
console.log(greeting); // Output: Hello, Alice!

let a = 5;
let b = 10;
console.log(`The sum of ${a} and ${b} is ${a + b}.`); // Output: The sum of 5 and 10 is 15.

// Multi-line Strings
let multiLineString = `This is a
multi-line
string.`;
console.log(multiLineString);
// Output:
// This is a
// multi-line
// string.
