//Primitive Types

//Number: Represents both integer and floating-point numbers. 
//JavaScript uses the IEEE 754 double-precision floating-point format. Example: 42, 3.14.
let age = 19
let weight = 120.8

//String: Represents a sequence of characters. 
//Strings can be enclosed in single quotes ('), double quotes ("), or backticks (`). Example: 'hello', "world", `hello world`.
let singleQuoteString = 'Hello, world!';
let doubleQuoteString = "Hello, world!";
let templateLiteralString = `Hello, world!`;

//Boolean: Represents a logical value, either true or false. Example: true, false.
let sunny = true;
let raining = false;

//Undefined: Indicates that a variable has been declared but has not been assigned a value.
let x;
console.log(x)

//Null: Represents the intentional absence of any object value
let a = null
console.log(a)

//BigInt: Represents integers with arbitrary precision. Useful for working with large integers. 
const bigIntValue = 1234567890123456789012345678901234567890n;
console.log(bigIntValue)