var a = 1;
console.log('log for variable named a outside scope =>',a)
{
    var a = 2
    console.log('log for variable named a inside scope =>',a)
}
console.log('log for variable named a outside scope =>',a)


