let a = 1;
console.log('log for variable named a=>',a);
a = 2;
console.log('log for variable named a=>',a);

console.log('log for variable named a outside scope =>',a)
{
    let a = 3
    console.log('log for variable named a inside scope =>',a)
}
console.log('log for variable named a outside scope =>',a)
