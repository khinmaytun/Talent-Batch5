let numbers = [1, 2, 3, 4];
let doubled = numbers.map(function(number) {
  return number * 2;
});
console.log(doubled);  // [2, 4, 6, 8]
