//for (initialization; condition; increment) {
    // code block to be executed
 // }
  

for (let i = 0; i < 5; i++) {
    console.log(i);
  }
  

