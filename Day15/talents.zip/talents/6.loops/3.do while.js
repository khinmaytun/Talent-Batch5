let i = 0;

do {
  console.log(i);
  i++;
} while (i < 5);

