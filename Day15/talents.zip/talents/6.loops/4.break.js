for (let i = 0; i < 10; i++) {
    if (i === 5) {
      break;
    }
    console.log(i);
  }
  // Output: 0, 1, 2, 3, 4
  