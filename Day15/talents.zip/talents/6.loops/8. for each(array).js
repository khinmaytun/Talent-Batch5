let fruits = ['Apple', 'Banana', 'Orange'];
fruits.forEach(function(fruit) {
    console.log(fruit);
});
  