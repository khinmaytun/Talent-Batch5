//used to iterate over iterable objects like arrays, strings, maps, sets, etc
let fruits = ['Apple', 'Banana', 'Orange'];

for (let fruit of fruits) {
  console.log(fruit);
}
// Output: Apple, Banana, Orange