let fruits = ['Apple', 'Banana', 'Orange'];
let citrus = fruits.slice(1, 3);
console.log(citrus);  // ['Banana', 'Orange']
