const fruits = ['apple', 'orange', 'grape']

console.log(fruits[0])
console.log(fruits[2])