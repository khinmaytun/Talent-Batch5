let fruits = ['Apple', 'Banana', 'Orange'];
fruits.splice(1, 1, 'Mango');
console.log(fruits);  // ['Apple', 'Mango', 'Orange']
