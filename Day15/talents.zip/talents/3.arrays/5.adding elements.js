const fruits = ['apple', 'orange', 'grape']

console.log(fruits)

fruits.push('mango')

console.log(fruits)

fruits.unshift('cucumber')

console.log(fruits)