const fruits = new Array('apple', 'orange', 'grape')
console.log(fruits)