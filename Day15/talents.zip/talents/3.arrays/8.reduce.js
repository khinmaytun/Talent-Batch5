let numbers = [1, 2, 3, 4];
let sum = numbers.reduce(function(total, number) {
  return total + number;
}, 0);
console.log(sum);  // 10
