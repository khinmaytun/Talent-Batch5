const fruits = ['apple', 'orange', 'grape']

console.log(fruits[0])
fruits[0] = "mango"
console.log(fruits[0])