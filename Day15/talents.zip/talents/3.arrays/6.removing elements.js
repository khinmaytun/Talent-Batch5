const fruits = ['apple', 'orange', 'grape', 'mango']

console.log(fruits)

fruits.pop()
console.log(fruits)

fruits.shift()
console.log(fruits)