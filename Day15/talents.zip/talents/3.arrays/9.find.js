let numbers = [1, 3, 4, 2];
let firstEven = numbers.find(function(number) {
  return number % 2 === 0;
});
console.log(firstEven);  // 2



let firstEvenIndex = numbers.findIndex(function(number) {
  return number % 2 === 0;
});
console.log(firstEvenIndex);  // 1

