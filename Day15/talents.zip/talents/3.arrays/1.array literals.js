const fruits = ['apple', 'orange', 'grape']

console.log(fruits)

console.log(fruits.length)