let age = 20;
let hasLicense = true;

if (age >= 18 && hasLicense) {
  console.log('You can drive.');
}
