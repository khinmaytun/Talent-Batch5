let age = 25;
let hasLicense = true;

if (age >= 18) {
  if (hasLicense) {
    console.log('You can drive.');
  } else {
    console.log('You need a driver\'s license.');
  }
} else {
  console.log('You are too young to drive.');
}
