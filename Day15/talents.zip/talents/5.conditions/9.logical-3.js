let isRaining2 = false;

if (!isRaining2) {
  console.log('You can go outside.');
}


let isRaining = true;

if (isRaining) { //isRaining(declare) == (isRaining=>true) // isRaining(declare) == (!isRaining=>true)
  console.log('Take an umbrella!'); // This will not run because isRaining is false
} else {
  console.log('You can go outside.'); // This will run because isRaining is false
}


let isLoggedIn = false; // User is not logged in

if (!isLoggedIn) {
  console.log('Please log in to continue.'); // This will run
} else {
  console.log('Welcome back!'); // This will not run
}