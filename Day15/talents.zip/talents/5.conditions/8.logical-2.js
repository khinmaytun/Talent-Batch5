let age = 16;
let hasParentalConsent = true;

if (age >= 18 || hasParentalConsent) {
  console.log('You can participate.');
}
