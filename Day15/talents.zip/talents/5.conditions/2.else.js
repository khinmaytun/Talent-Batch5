let item = 'apple'

if(item == 'orange'){
    console.log("it is orange")
}else{
    console.log("it is not an orange")
}

