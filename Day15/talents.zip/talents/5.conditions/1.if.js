let a = 1
let b = 2

if(a == b){
    console.log("a is equal to b")
}

if(a > b){
    console.log("a is greater than b")
}

if(a < b){
    console.log("a is less than b")
}