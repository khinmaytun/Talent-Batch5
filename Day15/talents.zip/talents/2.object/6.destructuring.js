const person = {
    pername: "U Mya",
    age: 12,
    eye_color: "blue",
    height: 100,
    weight: 100
}

const { pername, age, eye_color } = person

console.log(pername, age, eye_color)