const person = new Object()
person.name = "U Mya"
person.age = 12
person.greet = function () {
    console.log("Hello ", person.name)
}

console.log("name =>", person.name)
console.log("age =>", person.age)

person.greet()