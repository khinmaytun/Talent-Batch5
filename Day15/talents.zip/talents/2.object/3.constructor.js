function Person(name, age, gender) {
    this.fullName = name
    this.age = age
    this.gender = gender
    this.greeting = function(){
        console.log("hello", this.fullName)
    }
}

const student = new Person("Mg Mg", 12, "Male")

console.log(student instanceof Object)
// student.greeting()