const person = {
    name: "U Mya",
    age: 12,
    eye_color: "blue",
    height: 100,
    weight: 100,
    walk: function (direction) {
        console.log("walking ", direction)
    }
}

console.log(Object.keys(person)); 
console.log(Object.values(person)); 
console.log(Object.entries(person));