let person = {
    name: "U Mya",
    age: 12,
    eye_color: "blue"
}

console.log(person)

const newPerson = {...person, weight: 100, height: 100}

console.log(newPerson)