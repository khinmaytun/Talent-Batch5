const person = {
    name: "U Mya",
    age: 12,
    eye_color: "blue",
    height: 100,
    weight: 100
}

console.log(person)
delete person.age
console.log(person)