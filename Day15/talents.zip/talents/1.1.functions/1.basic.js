function functionName(parameters) {
    // Code to be executed
}

function greet(name) {
    return `Hello, ${name}!`;
}

console.log(greet('Mg Mg')); // "Hello, Mg Mg!"
  