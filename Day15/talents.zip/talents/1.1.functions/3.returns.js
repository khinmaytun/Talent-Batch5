function square(num) {
    return num * num;
}
  
const result = square(4);
console.log(result); // 16
  