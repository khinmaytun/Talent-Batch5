const functionName = function(parameters) {
    // Code to be executed
};

const add = function(a, b) {
    return a + b;
};
  
console.log(add(2, 3)); // 5

let x=10;
let a = x + 9;
  