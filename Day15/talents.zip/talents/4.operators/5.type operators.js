let x = 10;
let y = 'Hello';
let z = [1, 2, 3];

console.log(typeof x);  // "number"
console.log(typeof y);  // "string"
console.log(typeof z);  // "object"

console.log(z instanceof Array);  // true
console.log(y instanceof String); // false, because y is a string literal, not an instance of the String object

let a = new String('Hello');
console.log(a instanceof String) //true