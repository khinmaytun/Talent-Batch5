let x = 10;

x += 5;   // Equivalent to x = x + 5
console.log(x);  // 15

x -= 3;   // Equivalent to x = x - 3
console.log(x);  // 12

x *= 2;   // Equivalent to x = x * 2
console.log(x);  // 24

x /= 4;   // Equivalent to x = x / 4
console.log(x);  // 6

x %= 3;   // Equivalent to x = x % 3
console.log(x);  // 0

x **= 2;  // Equivalent to x = x ** 2
console.log(x);  // 0 (since x was 0 after the previous operation)
