let a = true;
let b = true;

console.log(a && b);  // Logical AND: false
console.log(a || b);  // Logical OR: true
console.log(!a);      // Logical NOT: false
