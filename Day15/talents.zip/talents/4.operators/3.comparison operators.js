let a = 10;
let b = 5;

console.log(a == b);   // Equal to: false
console.log(a != b);   // Not equal to: true
console.log(a === b);  // Strict equal to (checks value and type): false
console.log(a !== b);  // Strict not equal to (checks value and type): true
console.log(a > b);    // Greater than: true
console.log(a >= b);   // Greater than or equal to: true
console.log(a < b);    // Less than: false
console.log(a <= b);   // Less than or equal to: false
